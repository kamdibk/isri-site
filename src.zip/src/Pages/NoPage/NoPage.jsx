import React from 'react'

const NoPage = () => {
  return (
    <center style={{marginTop:"2rem"}}>
      <h1>
        BANNE KA HAI RE, SABAR RAKH...
      </h1>
    </center>
  )
}

export default NoPage
