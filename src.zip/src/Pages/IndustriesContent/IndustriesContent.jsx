import React from 'react'

const IndustriesContent = () => {
  return (
    <div>IndustriesContent</div>
  )
}

export default IndustriesContent