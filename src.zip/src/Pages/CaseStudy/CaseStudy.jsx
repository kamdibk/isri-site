import React from 'react'

const CaseStudy = () => {
  return (
    <div>CaseStudy</div>
  )
}

export default CaseStudy