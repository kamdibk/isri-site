import React from 'react'

const TechnologiesContent = () => {
  return (
    <div>TechnologiesContent</div>
  )
}

export default TechnologiesContent