export const NavbarData = [
  {
    title: "Services",
    subNav: [
      {
        title: "Software Development",
        link: "",
      },
      {
        title: "eCommerece Solutions",
        link: "",
      },
      {
        title: "Mobile Apps Development",
        link: "",
      },
      {
        title: "Cloud Solution",
        link: "",
      },
      {
        title: "CMS Solutions",
        link: "",
      },
      {
        title: "CRM Solutions",
        link: "",
      },
      {
        title: "Web Design",
        link: "",
      },
      {
        title: "Hire Developer",
        link: "",
      },
      {
        title: "Ride Booking",
        link: "",
      },
      {
        title: "Gaming Solution",
        link: "",
      },
      {
        title: "AI/ML",
        link: "",
      },
      {
        title: "Robotics Process Automation",
        link: "",
      },
    ],
  },
  {
    title: "Technologies",
  },
  {
    title: "Industries",
    subNav: [
      {
        title: "Medical & Healthcare",
        link: "",
      },
      {
        title: "Education",
        link: "",
      },
      {
        title: "Banking & Finance",
        link: "",
      },
      {
        title: "Media & Entertainment",
        link: "",
      },
      {
        title: "Retail & Wholesale",
        link: "",
      },
      {
        title: "Consumer Products",
        link: "",
      },
      {
        title: "Travel",
        link: "",
      },
      {
        title: "Real Estate",
        link: "",
      },
      {
        title: "Automotive",
        link: "",
      },
    ],
  },
  {
    title: "About Us",
    subNav: [
      {
        title: "Comapany",
        link: "",
      },
      {
        title: "Partners & Awards",
        link: "",
      },
      {
        title: "Clients Testimonial",
        link: "",
      },
      {
        title: "Quality Assurance",
        link: "",
      },
      {
        title: "Our Clients",
        link: "",
      },
      {
        title: "Careers",
        link: "",
      },
      {
        title: "Development Approach",
        link: "",
      },
      {
        title: "Communication Strategy",
        link: "",
      },
      {
        title: "Social Responsibility",
        link: "",
      },
    ],
  },
  {
    title: "Portfolio",
  },
  {
    title: "Case Study",
  },
  {
    title: "Blog",
  },
];
