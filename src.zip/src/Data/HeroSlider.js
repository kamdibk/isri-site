import SharepointLogo from "../../images/sharepointlogo.png";
import www from '../../images/www.png'
import appIcon from '../../images/mobileAppIcon.png'

export const heroSliderData = [
    {
        icon : " ",
    }
]