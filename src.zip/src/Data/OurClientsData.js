export const OurClientsData = [
    {
        key : 0,
        icon: "hi"
    },
    {
        key : 1,
        icon: "hi"
    },
    {
        key : 2,
        icon: "hi"
    },
    {
        key : 3,
        icon: "hi"
    },
    {
        key : 4,
        icon: "hi"
    },
    {
        key : 5,
        icon: "hi"
    },
    {
        key : 6,
        icon: "hi"
    },
    {
        key : 7,
        icon: "hi"
    },
    {
        key : 8,
        icon: "hi"
    },
    {
        key : 9,
        icon: "hi"
    },
    {
        key : 10,
        icon: "hi"
    },
    {
        key : 11,
        icon: "hi"
    },
    {
        key : 12,
        icon: "hi"
    },
    {
        key : 13,
        icon: "hi"
    },
    {
        key : 14,
        icon: "hi"
    },
    {
        key : 15,
        icon: "hi"
    },
    {
        key : 16,
        icon: "hi"
    },
    {
        key : 17,
        icon: "hi"
    },
    {
        key : 18,
        icon: "hi"
    },
    {
        key : 19,
        icon: "hi"
    },
    {
        key : 20,
        icon: "hi"
    },
    {
        key : 21,
        icon: "hi"
    },
    {
        key : 22,
        icon: "hi"
    },
]